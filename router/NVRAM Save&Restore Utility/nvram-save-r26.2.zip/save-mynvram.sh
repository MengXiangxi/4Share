#!/bin/sh

# save-mynvram.sh
# Save specified nvram user variables for restore

# Changelog
#------------------------------------------------
# Version 1			    30-April-2016
# - initial release
#------------------------------------------------
# variable definitions
version=1

setstring="nvram set"
cmdopts="$*"
scr_name=$(basename $0)
cwd=$(dirname $(readlink -f $0))
outfile="$cwd/restore-mynvram.sh"
tmpfile="$outfile.tmp"
count=0

# initialize the restore script
echo "#!/bin/sh" >$tmpfile

if [[ $# -eq 0 ]]; then
	echo "Usage:  save-mynvram.sh var1 var2 var3 ..."
	echo -e "\t where var1 var2 var3 ... are the names of the NVRAM vars to save"
	echo ""
	exit 0
fi

echo ""
while [[ $# -gt 0 ]]; do
	var=$1
	value=$(nvram get $1)
        lval=$(echo ${#value})
        if [ $lval -gt 0 ]; then
	    	value=${value//$/\\$} 		# escape $ char
	    	value=${value//\"/\\\"}		# escape " char
	    	value=${value//\`/\\\`} 	# escape ` char
	    	esc=`expr index "$value" $'\n'`	# check for lf escape sequence
	else
		echo "Skipping $var (empty or does not exist)"
		shift
		continue
	fi
	let count=count+1
	echo "Saving $var"
	echo "echo \"Restoring $var\"" >>$tmpfile
	if [ $esc -gt 0 ]; then
		valuex=${value//$'\r'/}		# remove cr
		valuex=${valuex//$'\n'/\\n}	# convert lf to escape sequence
       		echo "$setstring $var=\"\$(echo -e \"$valuex\")\"" >>$tmpfile
	else
		echo "$setstring $var=\"$value\"" >>$tmpfile
	fi

	shift
done

if [[ $count -gt 0 ]]; then
	if [[ -e "$outfile" ]]; then
		echo "Backing up previous restore script to $outfile.bak"
		cp -f $outfile $outfile.bak
	fi
	echo "echo \"\"" >>$tmpfile
	echo "echo \"Restore complete - $count NVRAM variable(s)\"" >>$tmpfile
	echo "echo \"Enter 'nvram commit' then reboot to activate your restored settings\"" >>$tmpfile
	cp -f $outfile.tmp $outfile
	chmod a+rx $outfile
	rm $outfile.tmp
	echo ""
	echo "Saved $count NVRAM variable(s)"
	echo "Run $outfile to restore your saved settings"
	echo ""
fi

exit 0
