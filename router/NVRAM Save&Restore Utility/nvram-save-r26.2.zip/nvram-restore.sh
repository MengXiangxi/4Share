#!/bin/sh

# nvram-restore.sh
# General front end to calling generated
# nvram-restore-yyyymmdd-macid scripts
# Supports OEM and Merlin firmware ONLY

# Changelog
#------------------------------------------------
# Version 26.1			    15-September-2017
# - minor prompt change
#
# Version 26.0			    16-Aug-2017
# - change version numbering
# - updates for migration and clean restore
# - alert for mac address mismatch instead of aborting
#
# Version 25			    8-Aug-2017
# - support doing a migration restore from a full save file
# - fix run log formatting
#
# Version 24			    2-May-2016
# - version update only
#
# Version 23			    3-April-2016
# - add help text for clean restore
#
# Version 22			    27-October-2015
# - add ini version to runlog
# - version variable name update
#
# Version 21			    6-August-2015
# - version update only
#
# Version 20			    3-August-2015
# - enable running script from other than current directory
#
# Version 19			     16-June-2015	
# - version update only for ini
#
# Version 18			     14-June-2015
# - prompt for clean restore with file generated
#   by latest level
# - add codelevel to runlog
# - added exit for no valid restore scripts
#
# Version 17			    29-April-2015
# - version update only for ini
#
# Version 16			    16-April-2015
# - first release as part of Version 16 package	
# - use last run for restore if none specified
#
#------------------------------------------------

Version=26.1
restore_version=$1
opt=""
scr_name=$(basename $0)
#cwd=$(pwd)
cwd=$(dirname $(readlink -f $0))
if [[ -d "$cwd/backup" ]]; then
	dwd=$cwd/backup;
else
	dwd=$cwd
fi
runlog="$cwd/nvram-util.log"
space4="    "
codelevel=""


echo ""
if [ "$restore_version" == "" ] || [ "$1" == "Y" ]; then
	macid=$(nvram get "et0macaddr")
	if [ "$macid" = "" ]; then
		macid=$(nvram get "et1macaddr")
	fi
	macid=`echo $macid | cut -d':' -f 5,6 | tr -d ':' | tr 'a-z' 'A-Z'`
	restore_version=`grep "nvram-save.sh" $runlog | tail -1 | awk -F' ' '{print $2}'`
	if [ "$restore_version" == "" ]; then
		echo "No valid nvram-save file found. Exiting."
		echo ""
		exit 3
	fi
	macsave=`echo -n $restore_version | tail -c 4`
		
	if [ "$1" != "Y" ]; then
		if [ "$macsave" != "$macid" ]; then
			echo "Last nvram save/restore (nvram-restore-$restore_version.sh)"
			echo "WARNING: Last nvram-save MAC address ($macsave)"
			echo "  does not match current router MAC  ($macid)!"
			echo "This may be valid if you are migrating settings from one router to another"
			echo ""
			read -p "Do you want to proceed [Y/N]?" input
			case "$input" in
		        	"Y"|"y")
	        			continue
		       			;;
	        		*)
	                		echo ""
	                		echo "Exiting - Restore aborted"
					
	                		echo ""
	                		exit 2
	                		;;
	        		esac
			echo ""
		fi
		echo "If you wish to use a different restore file, answer N and specify the"
		echo "  restore file id on the command line in the form"
		echo "  yyyymmddhhmm-mmmm"
		echo ""
		read -p "Restore using last nvram save (nvram-restore-$restore_version.sh) [Y/N]?" input
		case "$input" in
	        	"Y"|"y")
        			continue
	       			;;
        		*)
                		echo ""
                		echo "Exiting - Restore aborted"
                		echo ""
                		exit 1
                		;;
        		esac
	fi
fi
restore_file="nvram-restore-"$restore_version".sh"
echo ""
if [ ! -f "$dwd/$restore_file" ]; then
        echo "Script $dwd/$restore_file does not exist. Exiting."
        echo ""
        exit 1
fi

if [ "$1" == "Y" ]; then 
	opt="-clean"
fi

grep -q "Migrate restore from full restore supported" $dwd/$restore_file
if [ $? = 0 ] && [ "$macsave" != "MIGR" ]; then
	if [ "$opt" == "" ] && [ "$macsave" != "$macid" ]; then
		echo ""
		echo "A migration restore is used when transferring settings from one"
		echo "  router to another, even if they are both the same model type"
		echo "This option skips restoring some NVRAM variables which are unique"
		echo "  to a specific router, such as the Router Name, which by default is" 
		echo "  based on the router MAC address."
		echo "If you are restoring to a different router from that used to generate the"
		echo "  nvram-save, you should answer Y to the migration restore prompt"
		echo ""
		read -p "Perform a migration restore [Y/N]?" input
			case "$input" in
		        	"Y"|"y")
					opt="-migr"
					continue
		       			;;
        			*)
					opt=""
        	        		;;
        			esac
	fi
else
	if [ "$macsave" == "MIGR" ]; then
		echo "Performing a migration restore from a migration nvram-save"
		opt="-clean"
	else
		echo "Migration restore from a full nvram-save is not supported on this save file"
		echo ""
		read -p "Do you want to proceed [Y/N]?" input
		case "$input" in
	        	"Y"|"y")
        			continue
	       			;;
        		*)
                		echo ""
                		echo "Exiting - Restore aborted"
				
                		echo ""
                		exit 2
                		;;
        		esac
		opt=""
	fi
fi

#grep -q "Clean restore supported" $dwd/$restore_file
#if [ $? = 0 ]; then
	if [ "$opt" == "" ]; then
		echo ""
		echo "A clean restore will restore only those NVRAM settings"
		echo "  which have been initialized by the router after a factory reset"
		echo "This option should by used when reverting to an earlier"
		echo "  firmware level, when updating past a single firmware release," 
		echo "  when moving betwwen OEM and Merlin firmware or"
		echo "  to ensure any special use or obsolete NVRAM variables are cleared"
		echo "If in doubt, answer Y to perform a clean restore"
		echo ""
		read -p "Perform a clean restore and remove ununsed NVRAM variables [Y/N]?" input
			case "$input" in
		        	"Y"|"y")
					opt="-clean"
					continue
		       			;;
        			*)
					opt=""
        	        		;;
        			esac
	fi
#fi

# Run the restore
sh $dwd/$restore_file $opt

# Update runlog
codelevel=$(grep "codelevel=" $dwd/$restore_file | awk -F'=' '{print $2}')
version=$(grep "#Version=" $dwd/$restore_file | awk -F'=' '{print $2}')
echo "$(printf "%-20s" $scr_name)$(printf "%-20s" $restore_version)$(date)$space4$(printf "%-20s" $codelevel)#Version=$version" >>$runlog
echo ""
exit 0
