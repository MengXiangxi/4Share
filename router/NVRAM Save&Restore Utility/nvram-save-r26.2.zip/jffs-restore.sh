#!/bin/sh

# jffs-restore.sh
# Save jffs directory for restore after factory reset
# Supports OEM and Merlin firmware ONLY

# Changelog
#------------------------------------------------
# Version 26.1			  15-September-2017
# - query on mac mismatch
#
# Version 26.0			  31-August-2017
# - version update only
#
# Version 25			  8-August-2017
# - fix run log formatting
#
# Version 24			  2-May-2016
# - version update only
#
# Version 23			  3-April-2016
# - version update only
#
# Version 22			  27-October-2015
# - version variable name update
#
# Version 21			  6-August-2015
# - version update only
#
# Version 20			  3-August-2015
# - enable running script from other than current directory
#
# Version 19			  16-June-2015	
# - version update only for ini
#
# Version 18			  14-June-2015
# - added exit for no restore directory found
#
# Version 17			  29-April-2015
# - version update only for ini
#
# Version 16			  16-April-2015
# - use last run for restore if none specified
#
# Version 15			  25-February-2015
# - version update only
#
# Version 14			  7-February-2015
# - log results to syslog
#
# Version 12			  1-February-2015
# - do not hardcode jffs restore directory parent
#
# Version 11                      29-January-2015
# - no change
#
# Version 10 - first package release
# - restore /jffs directory       18-January-2015
#
#------------------------------------------------

Version=26.1
jffs_version=$1
if [ "${jffs_version:0:4}" == "jffs" ]; then
	jffs_dir=$jffs_version
	jffs_version=${jffs_version:5:13}
else
	jffs_dir="jffs-"$jffs_version
fi
scr_name=$(basename $0)
#cwd=$(pwd)
cwd=$(dirname $(readlink -f $0))
if [[ -d "$cwd/backup" ]]; then
	dwd=$cwd/backup;
else
	dwd=$cwd
fi
runlog="$cwd/nvram-util.log"

echo ""
if [ "$jffs_version" == "" ]; then
	macid=$(nvram get "et0macaddr")
	if [ "$macid" = "" ]; then
		macid=$(nvram get "et1macaddr")
	fi
	macid=`echo $macid | cut -d':' -f 5,6 | tr -d ':' | tr 'a-z' 'A-Z'`
	jffs_version=`grep "jffs-save" $runlog | tail -1 | awk -F' ' '{print $2}'`
	if [ "$jffs_version" == "" ]; then
		echo "No valid jffs saved directories found. Exiting."
		echo ""
		exit 3
	fi
	macsave=`echo -n $jffs_version | tail -c 4`

	if [ "$macsave" != "$macid" ]; then
		echo "Last jffs save (jffs-$jffs_version.sh)"
		echo "WARNING: Last jffs-save MAC address ($macsave)"
		echo "  does not match current router MAC  ($macid)!"
		echo "This may be valid if you are migrating settings from one router to another"
		echo ""
		read -p "Do you want to proceed [Y/N]?" input
			case "$input" in
		        	"Y"|"y")
	        			continue
		       			;;
	        		*)
	                		echo ""
	                		echo "Exiting - Restore aborted"
					
	                		echo ""
	                		exit 2
	                		;;
	        		esac
		echo ""
	fi
	
	jffs_dir="jffs-"$jffs_version
	echo "If you wish to use a different restore file, answer N and specify the"
	echo "  saved directory file id on the command line in the form"
	echo "  yyyymmddhhmm-mmmm"
	echo ""
	read -p "Restore last saved directory ($jffs_dir) [Y/N]?" input
	case "$input" in
	        "Y"|"y")
        		continue
	       		;;
        	*)
                	echo ""
                	echo "Exiting - Restore aborted"
                	echo ""
                	exit 1
                	;;
        	esac
fi

echo ""
if [ ! -d "$dwd/$jffs_dir" ]; then
        echo "Directory $jffs_dir does not exist. Exiting."
        echo ""
        exit 1

fi

echo ""
echo "WARNING:  This will overwrite/replace the current contents of your /jffs directory"
read -p "Do you want to continue [Y/N] " input
case "$input" in
        "Y"|"y")
		echo ""
		logger -s -t $scr_name "JFFS Restore Utility - Version "$version
		logger -s -t $scr_name "Restoring /jffs directory:  "$jffs_dir
        	echo "Deleting current contents of /jffs"
        	rm -r /jffs/*
        	echo "Restoring /jffs"
		cp -af "$dwd/$jffs_dir/." /jffs
                logger -s -t $scr_name  "/jffs restored from "$dwd"/"$jffs_dir
                echo ""
                ;;
        *)
                echo ""
                logger -s -t $scr_name  "Exiting - Restore aborted"
                echo ""
                exit 1
                ;;
        esac

echo "$(printf "%-20s" $scr_name)$(printf "%-20s" $jffs_version)$(date)" >>$runlog

echo "Please reboot manually"
echo ""
exit 0
